console.log("Plantio");
console.log(plantio);
console.log("Colheita");
console.log(colheita);
